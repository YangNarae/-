import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class BufferedReaderUse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		// String input = "a";
		// while (true) {
		// try {
		// input = in.readLine();
		// if (input.equals("quit")) {
		// break;
		// }
		// System.out.println(input);
		// } catch (IOException e) {
		// System.out.println(e);
		// }
		// }
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
			String input = in.readLine();
			StringTokenizer s = new StringTokenizer(input);
			System.out.println("There are " + Integer.valueOf(s.countTokens()) + " words in this line.");
			while (s.hasMoreTokens()) {
				System.out.println(s.nextToken());
			}
		} catch (IOException e) {
			;
		}
	}

}
